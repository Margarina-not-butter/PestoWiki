# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'settings.ui'
##
## Created by: Qt User Interface Compiler version 6.9.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDialog, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(400, 300)
        self.verticalLayout = QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.scrollArea = QScrollArea(Dialog)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 380, 280))
        self.checkExternalLinks = QCheckBox(self.scrollAreaWidgetContents)
        self.checkExternalLinks.setObjectName(u"checkExternalLinks")
        self.checkExternalLinks.setGeometry(QRect(10, 10, 261, 23))
        self.labelWikiAddress = QLabel(self.scrollAreaWidgetContents)
        self.labelWikiAddress.setObjectName(u"labelWikiAddress")
        self.labelWikiAddress.setGeometry(QRect(10, 80, 111, 18))
        self.leWikiAddress = QLineEdit(self.scrollAreaWidgetContents)
        self.leWikiAddress.setObjectName(u"leWikiAddress")
        self.leWikiAddress.setGeometry(QRect(10, 100, 361, 26))
        self.labelBookmarks = QLabel(self.scrollAreaWidgetContents)
        self.labelBookmarks.setObjectName(u"labelBookmarks")
        self.labelBookmarks.setGeometry(QRect(10, 130, 61, 18))
        self.btnFavoritesDelete = QPushButton(self.scrollAreaWidgetContents)
        self.btnFavoritesDelete.setObjectName(u"btnFavoritesDelete")
        self.btnFavoritesDelete.setGeometry(QRect(290, 150, 81, 26))
        self.btnFavoritesAdd = QPushButton(self.scrollAreaWidgetContents)
        self.btnFavoritesAdd.setObjectName(u"btnFavoritesAdd")
        self.btnFavoritesAdd.setGeometry(QRect(290, 180, 81, 26))
        self.lwFavorites = QListWidget(self.scrollAreaWidgetContents)
        self.lwFavorites.setObjectName(u"lwFavorites")
        self.lwFavorites.setGeometry(QRect(10, 150, 271, 121))
        self.btnFavoritesEdit = QPushButton(self.scrollAreaWidgetContents)
        self.btnFavoritesEdit.setObjectName(u"btnFavoritesEdit")
        self.btnFavoritesEdit.setGeometry(QRect(290, 210, 81, 26))
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.verticalLayout.addWidget(self.scrollArea)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.checkExternalLinks.setText(QCoreApplication.translate("Dialog", u"Abrir links externos no seu navegador.", None))
        self.labelWikiAddress.setText(QCoreApplication.translate("Dialog", u"Endere\u00e7o da wiki", None))
        self.labelBookmarks.setText(QCoreApplication.translate("Dialog", u"Favoritos", None))
        self.btnFavoritesDelete.setText(QCoreApplication.translate("Dialog", u"Deletar", None))
        self.btnFavoritesAdd.setText(QCoreApplication.translate("Dialog", u"Adicionar", None))
        self.btnFavoritesEdit.setText(QCoreApplication.translate("Dialog", u"Editar", None))
    # retranslateUi

